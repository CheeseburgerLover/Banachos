-- Mei Mei (Legendary): when she scores, the video plays (with sound) and she gives X1.77 Mult.
SMODS.Atlas{ key = 'meimei', path = 'meimei.png', px = 71, py = 95 }

local video = nil
local video_src = nil
local loaded = false

local function load_video()
    if loaded then return end
    loaded = true
    local mod = SMODS.findModByID and SMODS.findModByID('Banachos')
    if not (mod and mod.path) then return end
    local ok, v = pcall(love.graphics.newVideo, mod.path .. 'assets/meimei.ogv', { audio = true })
    if ok and v then
        video = v
        video_src = v.getSource and v:getSource() or nil
    end
end

local function play_video()
    if BANACHOS and BANACHOS.perf then return end
    load_video()
    if not video then return end
    video:rewind()
    video:play()
    if video_src then
        video_src:stop()
        video_src:play()
    end
end

BANACHOS_PLAY_VIDEO = function() play_video() end

local function video_playing()
    return video and video:isPlaying()
end

local old_draw = love.draw
function love.draw()
    old_draw()
    if not video_playing() then return end
    local W, H = love.graphics.getDimensions()
    local vw, vh = video:getWidth(), video:getHeight()
    local s = math.min(W / vw, H / vh)
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.draw(video, (W - vw * s) / 2, (H - vh * s) / 2, 0, s, s)
end

SMODS.Joker{
    key = 'meimei',
    atlas = 'meimei',
    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },
    config = { extra = { x_mult = 1.5 } },
    loc_txt = {
        ['name'] = 'Mei Mei',
        ['text'] = {
            [1] = 'Plays a video when scoring',
            [2] = 'and gives {X:mult,C:white}X#1#{} Mult',
            [3] = '{C:inactive}Art by Luna{}',
        },
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult } }
    end,
    rarity = 4,
    cost = 10,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,

    calculate = function(self, card, context)
        -- Encore: round ends with Mei Mei -> +1 discard and replay the video
        if context.end_of_round and context.cardarea == G.jokers and not context.blueprint then
            if BANACHOS_MEI_ENCORE then BANACHOS_MEI_ENCORE(card) end
            return
        end
        if context.joker_main then
            play_video()
            return { x_mult = card.ability.extra.x_mult, card = card }
        end
    end,
}
