-- Where is bro going
-- Discarding a Flush, Straight, Full House, Straight Flush or Royal Flush:
--   * Mult stacks: +30 to the stored Mult (base is 5)
--   * x1.33 is queued for the NEXT played hand only (each discard queues one more)
-- When you play a hand: the stored Mult above the base 5 is applied, then drops back to 5.
-- The queued x1.33s are applied to that hand, then cleared.
SMODS.Atlas{ key = 'whereisbro', path = 'whereisbro.png', px = 71, py = 95 }

local BASE = 5
local HANDS = { ['Flush'] = true, ['Straight'] = true, ['Full House'] = true,
                ['Straight Flush'] = true, ['Royal Flush'] = true }

SMODS.Joker{
    key = 'whereisbro',
    atlas = 'whereisbro',
    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },
    config = { extra = { mult = 30, x_mult = 1.33, base = BASE, stored = BASE, queued_x = 0 } },
    loc_txt = {
        ['name'] = 'Where is bro going',
        ['text'] = {
            [1] = 'Discarding a {C:attention}Flush{}, {C:attention}Straight{},',
            [2] = '{C:attention}Full House{}, {C:attention}Straight Flush{}',
            [3] = 'or {C:attention}#1#{} gives {C:mult}+#2#{} Mult (stacks)',
            [4] = 'and {X:mult,C:white}X#3#{} Mult on your next hand',
            [5] = '{C:inactive}(Stored Mult: #4#, queued X: #5#){}',
        },
    },
    loc_vars = function(self, info_queue, card)
        local royal = (G.GAME and G.GAME.hands and G.GAME.hands['Royal Flush']
                       and G.GAME.hands['Royal Flush'].played or 0) > 0
        local e = card.ability.extra
        return { vars = { royal and 'Royal Flush' or '???', e.mult, e.x_mult, e.stored,
                          string.format('%.2f', e.queued_x > 0 and (e.x_mult ^ e.queued_x) or 1) } }
    end,
    rarity = 2,
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,

    calculate = function(self, card, context)
        local e = card.ability.extra
        if context.pre_discard and G.hand and G.hand.highlighted and #G.hand.highlighted > 0 then
            local name = G.FUNCS.get_poker_hand_info(G.hand.highlighted)
            if HANDS[name] then
                e.stored = e.stored + e.mult
                e.queued_x = e.queued_x + 1
                return { message = 'Bro is going!', colour = G.C.MULT, card = card }
            end
        end
        if context.joker_main then
            local bonus = e.stored - e.base
            local xm = (e.queued_x > 0) and (e.x_mult ^ e.queued_x) or 1
            if bonus > 0 or e.queued_x > 0 then
                e.stored = e.base      -- Mult drops back to the base after it is used
                e.queued_x = 0         -- queued x1.33 is consumed by this hand
                return { mult = bonus, x_mult = xm, card = card }
            end
        end
    end,
}
