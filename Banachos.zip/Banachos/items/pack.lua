-- Banachos Pack: $8, shows 4 Banachos jokers, pick 1
local POOL = { 'j_banachos_threebirds', 'j_banachos_whereisbro', 'j_banachos_meimei', 'j_banachos_igotchu',
               'j_banachos_oldblue', 'j_banachos_oldblack', 'j_banachos_secretagent',
               'j_banachos_subway', 'j_banachos_happymeal', 'j_banachos_apple' }

SMODS.Booster{
    key = 'banachos_pack',
    kind = 'Joker',
    atlas = 'threebirds',
    pos = { x = 0, y = 0 },
    config = { extra = 4, choose = 1 },
    cost = 8,
    weight = 1,
    loc_txt = {
        name = 'Banachos Pack',
        text = { 'Choose {C:attention}1{} of {C:attention}4{}', '{C:attention}Banachos{} jokers' },
    },
    create_card = function(self, card, i)
        local key = POOL[math.floor(pseudorandom('banachos_pack') * #POOL) + 1]
        return { set = 'Joker', area = G.pack_cards, skip_materialize = true, key = key }
    end,
}
