-- Batch 2: Happy Meal, two Old Men, Secret Agent, Subway Joker
local function owns(suffix)
    if not G.jokers then return false end
    for _, c in ipairs(G.jokers.cards) do
        if c.config and c.config.center and c.config.center.key == 'j_banachos_' .. suffix then return true end
    end
    return false
end

local function max_played()
    local best, name = 0, nil
    for n, h in pairs(G.GAME.hands) do
        if h.played > best then best, name = h.played, n end
    end
    return best, name
end

-- ============ Happy Meal ============
SMODS.Atlas{ key = 'happymeal', path = 'happymeal.png', px = 71, py = 95 }

local function apply_buff(name, sign)
    local rr, cr = G.GAME.round_resets, G.GAME.current_round
    if name == 'size' then
        G.hand.config.card_limit = G.hand.config.card_limit + 2 * sign
    elseif name == 'discard' then
        rr.discards = rr.discards + sign
        cr.discards_left = cr.discards_left + sign
    elseif name == 'hand' then
        rr.hands = rr.hands + sign
        cr.hands_left = cr.hands_left + sign
    end
end

SMODS.Joker{
    key = 'happymeal',
    atlas = 'happymeal',
    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },
    config = { extra = { active = { size = true, discard = true, hand = true } } },
    loc_txt = {
        ['name'] = 'Happy Meal',
        ['text'] = {
            [1] = '{C:attention}+2{} hand size, {C:attention}+1{} discard, {C:attention}+1{} hand',
            [2] = 'End of round: {C:green}1/4{} chance to lose one buff',
            [3] = 'When all buffs are gone, explode and create',
            [4] = 'a {C:planet}Planet{} card for your most played hand',
        },
    },
    rarity = 3,
    cost = 6,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,

    add_to_deck = function(self, card, from_debuff)
        if from_debuff then return end
        for name, on in pairs(card.ability.extra.active) do
            if on then apply_buff(name, 1) end
        end
    end,
    remove_from_deck = function(self, card, from_debuff)
        if from_debuff then return end
        for name, on in pairs(card.ability.extra.active) do
            if on then apply_buff(name, -1) end
        end
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.cardarea == G.jokers and not context.blueprint then
            if pseudorandom('happymeal') < (G.GAME.banachos_hm_plus and 1/3 or 0.25) then
                local left = {}
                for name, on in pairs(card.ability.extra.active) do
                    if on then table.insert(left, name) end
                end
                table.sort(left)
                if #left > 0 then
                    local pick = left[math.floor(pseudorandom('happymeal_pick') * #left) + 1]
                    apply_buff(pick, -1)
                    card.ability.extra.active[pick] = false
                end
                if #left <= 1 then
                    -- all buffs gone: explode and give a planet for the most played hand
                    local _, hand = max_played()
                    if hand and G.consumeables then
                        for key, v in pairs(G.P_CENTERS) do
                            if v.set == 'Planet' and v.config and v.config.hand_type == hand then
                                local p = create_card('Planet', G.consumeables, nil, nil, nil, nil, key)
                                G.consumeables:emplace(p)
                                break
                            end
                        end
                    end
                    card:start_dissolve()
                    return { message = 'Boom!', colour = G.C.RED }
                end
            end
        end
    end,
}

-- ============ Old Men ============
SMODS.Atlas{ key = 'oldblue', path = 'oldblue.png', px = 71, py = 95 }
SMODS.Atlas{ key = 'oldblack', path = 'oldblack.png', px = 71, py = 95 }

SMODS.Joker{
    key = 'oldblue',
    atlas = 'oldblue',
    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },
    config = { extra = { chips = 100, mult = 15, bonus_chips = 15, bonus_mult = 75 } },
    loc_txt = {
        ['name'] = 'Ong Gia Ao Xanh',
        ['text'] = {
            [1] = '{C:chips}+#1#{} Chips, {C:mult}+#2#{} Mult',
            [2] = 'With Ong Gia Ao Den: {C:chips}+#3#{} Chips, {C:mult}+#4#{} Mult',
        },
    },
    loc_vars = function(self, info_queue, card)
        local e = card.ability.extra
        return { vars = { e.chips, e.mult, e.bonus_chips, e.bonus_mult } }
    end,
    rarity = 4,
    cost = 10,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    calculate = function(self, card, context)
        if context.joker_main then
            local e = card.ability.extra
            local c, m = e.chips, e.mult
            if owns('oldblack') then c, m = c + e.bonus_chips, m + e.bonus_mult end
            return { chips = c, mult = m, card = card }
        end
    end,
}

SMODS.Joker{
    key = 'oldblack',
    atlas = 'oldblack',
    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },
    config = { extra = { x_mult = 1.5, x_with_blue = 2.5 } },
    loc_txt = {
        ['name'] = 'Ong Gia Ao Den',
        ['text'] = {
            [1] = '{X:mult,C:white}X#1#{} Mult',
            [2] = 'With Ong Gia Ao Xanh: {X:mult,C:white}X#2#{} Mult',
        },
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult, card.ability.extra.x_with_blue } }
    end,
    rarity = 4,
    cost = 10,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    calculate = function(self, card, context)
        if context.joker_main then
            local e = card.ability.extra
            local x = owns('oldblue') and e.x_with_blue or e.x_mult
            return { x_mult = x, card = card }
        end
    end,
}

-- ============ Secret Agent ============
SMODS.Atlas{ key = 'secretagent', path = 'secretagent.png', px = 71, py = 95 }

SMODS.Joker{
    key = 'secretagent',
    atlas = 'secretagent',
    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },
    loc_txt = {
        ['name'] = 'Secret Agent',
        ['text'] = {
            [1] = '{X:mult,C:white}X1{} Mult, +{X:mult,C:white}0.2{} for each time',
            [2] = 'your most played hand has been played (max X5)',
        },
    },
    rarity = 2,
    cost = 7,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    calculate = function(self, card, context)
        if context.joker_main then
            local best = max_played()
            return { x_mult = math.min(1 + 0.2 * best, 5), card = card }   -- capped at X5
        end
    end,
}

-- ============ Subway Joker (animated) ============
SMODS.Atlas{ key = 'subway', path = 'subway.png', px = 71, py = 95 }

SMODS.Joker{
    key = 'subway',
    atlas = 'subway',
    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },
    loc_txt = {
        ['name'] = 'Subway Joker',
        ['text'] = {
            [1] = 'Converts {C:attention}10%{} of your Chips',
            [2] = 'into {C:mult}Mult{} (max {C:mult}60{})',
        },
    },
    rarity = 2,
    cost = 5,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    calculate = function(self, card, context)
        if context.joker_main and hand_chips then
            local rate = (BANACHOS_TURBO_ACTIVE and BANACHOS_TURBO_ACTIVE()) and 0.20 or 0.10
            local x = math.min(math.floor(hand_chips * rate), 60)
            if x > 0 then return { chips = -x, mult = x, card = card } end
        end
    end,
}
