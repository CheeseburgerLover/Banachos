-- Batch 3: ten ideas. Some are simplified; see the notes in each block.
local function owns(suffix)
    if not G.jokers then return false end
    for _, c in ipairs(G.jokers.cards) do
        if c.config and c.config.center and c.config.center.key == 'j_banachos_' .. suffix then return true end
    end
    return false
end

-- 1) Budgie Pack: locked until the Banachos Deck is unlocked; choose 2 of 4 Banachos jokers
SMODS.Atlas{ key = 'budgiepack', path = 'budgiepack.png', px = 71, py = 95 }
SMODS.Booster{
    key = 'budgie',
    kind = 'Joker',
    atlas = 'budgiepack', pos = { x = 0, y = 0 },
    config = { extra = 4, choose = 2 },
    cost = 6, weight = 1,
    unlocked = false,
    loc_txt = { name = 'Budgie Pack', text = { 'Choose {C:attention}2{} of {C:attention}4{}', '{C:attention}Banachos{} jokers' } },
    create_card = function(self, card, i)
        local pool = { 'j_banachos_threebirds', 'j_banachos_whereisbro', 'j_banachos_meimei', 'j_banachos_igotchu',
                       'j_banachos_oldblue', 'j_banachos_oldblack', 'j_banachos_secretagent', 'j_banachos_subway',
                       'j_banachos_happymeal', 'j_banachos_apple', 'j_banachos_crest', 'j_banachos_flock' }
        return { set = 'Joker', area = G.pack_cards, skip_materialize = true,
                 key = pool[math.floor(pseudorandom('budgie') * #pool) + 1] }
    end,
}
-- Unlock once the Banachos Deck is unlocked (checked every frame, cheap)
local old_update_unlock = Game.update
function Game:update(dt)
    old_update_unlock(self, dt)
    if not BANACHOS_BUDGIE_DONE then
        for k, v in pairs(G.P_CENTERS) do
            if v.set == 'Back' and k:find('banachos_banachos', 1, true) and v.unlocked then
                for kk, vv in pairs(G.P_CENTERS) do
                    if vv.set == 'Booster' and kk:find('budgie', 1, true) then vv.unlocked = true end
                end
                BANACHOS_BUDGIE_DONE = true
            end
        end
    end
end

-- 2) Cockatiel Crest (Rare): +1 Mult per Ace scored this hand, up to +50 (applied to this joker)
SMODS.Atlas{ key = 'crest', path = 'crest.png', px = 71, py = 95 }
SMODS.Joker{
    key = 'crest', atlas = 'crest', pos = { x = 0, y = 0 }, display_size = { w = 71, h = 95 },
    config = { extra = { aces = 0 } },
    loc_txt = { ['name'] = 'Cockatiel Crest', ['text'] = {
        '+{C:mult}1{} Mult per {C:attention}Ace{} scored', '(max {C:mult}+50{} per hand)' } },
    rarity = 3, cost = 8, unlocked = true, discovered = true, blueprint_compat = true, eternal_compat = true,
    calculate = function(self, card, context)
        if context.before then card.ability.extra.aces = 0 end
        if context.individual and context.cardarea == G.play and context.other_card and context.other_card:get_id() == 14 then
            card.ability.extra.aces = card.ability.extra.aces + 1
        end
        if context.joker_main and card.ability.extra.aces > 0 then
            return { mult = math.min(card.ability.extra.aces, 50), card = card }
        end
    end,
}

-- 3) Feather Seal: +chips that decay 1 per round (simplified: no retain-after-discard)
SMODS.Atlas{ key = 'feather', path = 'feather.png', px = 71, py = 95 }
SMODS.Atlas{ key = 'feather_seal', path = 'feather_seal.png', px = 71, py = 95 }
SMODS.Seal{
    key = 'feather', atlas = 'feather_seal', pos = { x = 0, y = 0 }, badge_colour = HEX('3E7CB1'),
    loc_txt = { label = 'Feather', name = 'Feather Seal', text = { '{C:chips}+#1#{} Chips, -1 each round' } },
    loc_vars = function(self, info_queue, card)
        return { vars = { (card and card.ability and card.ability.banachos_feather) or 10 } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            return { chips = card.ability.banachos_feather or 10, card = card }
        end
        if context.end_of_round and card.ability.banachos_feather then
            card.ability.banachos_feather = math.max(0, card.ability.banachos_feather - 1)
        end
    end,
}

-- 4) Nest Egg (Spectral): copy a random Banachos joker with Perishable (5 rounds)
SMODS.Atlas{ key = 'nest', path = 'nest.png', px = 71, py = 95 }
SMODS.Consumable{
    key = 'nest', set = 'Spectral', atlas = 'nest', pos = { x = 0, y = 0 },
    loc_txt = { name = 'Nest Egg', text = { 'Copy a random {C:attention}Banachos{} joker', 'It becomes {C:attention}Perishable{} (5 rounds)' } },
    can_use = function(self, card)
        return G.jokers and #G.jokers.cards > 0
    end,
    use = function(self, card, area, copier)
        local list = {}
        for _, c in ipairs(G.jokers.cards) do
            local k = c.config and c.config.center and c.config.center.key or ''
            if k:find('^j_banachos_') then table.insert(list, k) end
        end
        if #list == 0 then return end
        local key = list[math.floor(pseudorandom('nest') * #list) + 1]
        local c = create_card('Joker', G.jokers, nil, nil, nil, nil, key)
        c:add_to_deck()
        c.ability.perishable = true
        c.ability.perish_tally = 5
        G.jokers:emplace(c)
    end,
}

-- 5) Flock (Uncommon): every 5 rounds gains +0.1 X Mult stacks (shop slot penalty not implemented)
SMODS.Atlas{ key = 'flock', path = 'flock.png', px = 71, py = 95 }
SMODS.Joker{
    key = 'flock', atlas = 'flock', pos = { x = 0, y = 0 }, display_size = { w = 71, h = 95 },
    config = { extra = { rounds = 0, stacks = 0 } },
    loc_txt = { ['name'] = 'Flock Event', ['text'] = {
        'Every {C:attention}5{} rounds: {X:mult,C:white}+0.1{} X Mult stacks', 'Stacks: {X:mult,C:white}X#1#{}' } },
    loc_vars = function(self, info_queue, card)
        return { vars = { string.format('%.1f', 1 + 0.1 * card.ability.extra.stacks) } }
    end,
    rarity = 2, cost = 6, unlocked = true, discovered = true, blueprint_compat = true, eternal_compat = true,
    calculate = function(self, card, context)
        if context.end_of_round and context.cardarea == G.jokers and not context.blueprint then
            card.ability.extra.rounds = card.ability.extra.rounds + 1
            if card.ability.extra.rounds % 5 == 0 then card.ability.extra.stacks = card.ability.extra.stacks + 1 end
        end
        if context.joker_main and card.ability.extra.stacks > 0 then
            return { x_mult = 1 + 0.1 * card.ability.extra.stacks, card = card }
        end
    end,
}

-- 6) Birdcage Deck: starts with 3 random Banachos jokers, 3 joker slots
SMODS.Atlas{ key = 'birdcage', path = 'birdcage.png', px = 71, py = 95 }
SMODS.Back{
    key = 'birdcage', atlas = 'birdcage', pos = { x = 0, y = 0 },
    loc_txt = { name = 'Birdcage Deck', text = { 'Start with {C:attention}3{} random', '{C:attention}Banachos{} jokers', '{C:attention}3{} joker slots' } },
    config = {}, unlocked = false,
    apply = function(self, back)
        local pool = { 'j_banachos_threebirds', 'j_banachos_whereisbro', 'j_banachos_meimei', 'j_banachos_igotchu',
                       'j_banachos_oldblue', 'j_banachos_oldblack', 'j_banachos_secretagent', 'j_banachos_subway',
                       'j_banachos_happymeal', 'j_banachos_apple', 'j_banachos_crest', 'j_banachos_flock' }
        G.E_MANAGER:add_event(Event({ func = function()
            if G.jokers then G.jokers.config.card_limit = 3 end
            return true end }))
        for i = 1, 3 do
            local key = pool[math.floor(pseudorandom('birdcage' .. i) * #pool) + 1]
            G.E_MANAGER:add_event(Event({ func = function()
                local c = create_card('Joker', G.jokers, nil, nil, nil, nil, key)
                c:add_to_deck(); G.jokers:emplace(c); return true end }))
        end
    end,
}

-- 7) Chirp Tarot: turns the highlighted cards into Lucky. (+15 chip for 3/6/9 not implemented)
SMODS.Atlas{ key = 'chirp', path = 'chirp.png', px = 71, py = 95 }
SMODS.Consumable{
    key = 'chirp', set = 'Tarot', atlas = 'chirp', pos = { x = 0, y = 0 },
    loc_txt = { name = 'Chirp', text = { 'Enhance {C:attention}1{} selected card', 'to {C:attention}Lucky{}' } },
    can_use = function(self, card)
        return G.hand and G.hand.highlighted and #G.hand.highlighted >= 1
    end,
    use = function(self, card, area, copier)
        for _, c in ipairs(G.hand.highlighted) do
            c:set_ability(G.P_CENTERS.m_lucky)
            break
        end
    end,
}

-- 8) Mei Mei Encore: when a round ends with Mei Mei, +1 discard and the video plays again
-- (zoom effect not implemented)
local old_mei_calc = SMODS.Jokers and nil
-- handled in meimei.lua via BANACHOS_MEI_ENCORE()
function BANACHOS_MEI_ENCORE(card)
    if G.GAME and G.GAME.current_round then
        G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + 1
    end
    if BANACHOS_PLAY_VIDEO then BANACHOS_PLAY_VIDEO() end
end

-- 9) Subway Turbo (Boss Blind): each hand played costs 1 discard; Subway converts twice as much
SMODS.Atlas{ key = 'turbo_blind', path = 'turbo_blind.png', px = 34, py = 34 }
SMODS.Blind{
    key = 'turbo', atlas = 'turbo_blind', pos = { x = 0, y = 0 },
    loc_txt = { name = 'Subway Turbo', text = { 'Each hand costs {C:attention}1{} discard', 'Subway converts {C:attention}double{}' } },
    boss = { min = 1 }, boss_colour = HEX('FF5A28'),
    mult = 2, dollars = 5,
    calculate = function(self, blind, context)
        if context.before then
            G.GAME.current_round.discards_left = math.max(0, G.GAME.current_round.discards_left - 1)
        end
    end,
}
BANACHOS_TURBO_ACTIVE = function()
    return G.GAME and G.GAME.blind and G.GAME.blind.config and G.GAME.blind.config.blind and G.GAME.blind.config.blind.key == 'turbo'
end

-- 10) Happy Meal+ (Voucher): Happy Meal loses buffs at 1/3 instead of 1/4 (limit +1 not implemented)
SMODS.Atlas{ key = 'happymealplus', path = 'happymealplus.png', px = 71, py = 95 }
SMODS.Voucher{
    key = 'happymealplus', atlas = 'happymealplus', pos = { x = 0, y = 0 }, cost = 10,
    loc_txt = { name = 'Happy Meal+', text = { 'Happy Meal buff loss chance', 'rises to {C:green}1/3{}' } },
    unlocked = true,
    redeem = function(self, card)
        G.GAME.banachos_hm_plus = true
    end,
}
