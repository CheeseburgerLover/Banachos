-- Apple Joker (Uncommon): doubles all shop prices. Retriggers Apple Seal cards once.
-- Apple Seal: +10 Chips, +5 Mult per scoring. Works with or without the Apple Joker, no retrigger.
SMODS.Atlas{ key = 'apple', path = 'apple.png', px = 71, py = 95 }
SMODS.Atlas{ key = 'apple_seal', path = 'apple_seal.png', px = 71, py = 95 }

local function owns_apple()
    if not G.jokers then return false end
    for _, c in ipairs(G.jokers.cards) do
        if c.config and c.config.center and c.config.center.key == 'j_banachos_apple' then return true end
    end
    return false
end

-- Real registered key of the Apple Seal (avoids setting an unknown seal key)
local function APPLE_SEAL_KEY()
    if not G.P_SEALS then return nil end
    for k, _ in pairs(G.P_SEALS) do
        if type(k) == 'string' and k:find('apple', 1, true) then return k end
    end
    return nil
end

-- Shop prices x2
local old_set_cost = Card.set_cost
function Card:set_cost()
    old_set_cost(self)
    if owns_apple() and self.area and (self.area == G.shop_jokers or self.area == G.shop_booster or self.area == G.shop_vouchers) then
        self.cost = self.cost * 2
    end
end

SMODS.Seal{
    key = 'apple',
    atlas = 'apple_seal',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('2E9E44'),
    loc_txt = {
        label = 'Apple',
        name = 'Apple Seal',
        text = { '{C:chips}+10{} Chips', '{C:mult}+5{} Mult', '{X:mult,C:white}X1.125{} Mult' },
    },
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            return { chips = 10, mult = 5, x_mult = 1.125, card = card }
        end
    end,
}

SMODS.Joker{
    key = 'apple',
    atlas = 'apple',
    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },
    loc_txt = {
        ['name'] = 'Apple Joker',
        ['text'] = {
            [1] = 'Shop prices are {C:money}doubled{}',
            [2] = 'Retrigger {C:attention}Apple Seal{} cards once',
            [3] = 'First scoring card each hand gets the {C:attention}Apple Seal{}',
        },
    },
    rarity = 2,
    cost = 5,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    calculate = function(self, card, context)
        local target = context.other_card
        if context.repetition and context.cardarea == G.play and target and target.seal and target.seal == APPLE_SEAL_KEY() then
            return { repetitions = 1, card = target }
        end
        if context.before and context.scoring_hand and context.scoring_hand[1] then
            local first = context.scoring_hand[1]
            local key = APPLE_SEAL_KEY()
            if key and not first.seal then first:set_seal(key, true) end
        end
    end,
}
