-- Banachos decks. Unlock is checked when a run is won (G.GAME.won).
local function jokers()
    return G.jokers and G.jokers.cards or {}
end

local function key_of(c)
    return c.config and c.config.center and c.config.center.key or ''
end

local function add_joker(key, eternal)
    G.E_MANAGER:add_event(Event({ func = function()
        local c = create_card('Joker', G.jokers, nil, nil, nil, nil, key)
        c:add_to_deck()
        G.jokers:emplace(c)
        if eternal then c:set_eternal(true) end
        return true
    end }))
end

-- Old Deck: x3 blind chips, starts with both old men
SMODS.Back{
    key = 'old',
    atlas = 'oldblue', pos = { x = 0, y = 0 },
    loc_txt = { name = 'Old Deck', text = { 'Start with {C:attention}2{} Old Men', '{X:red,C:white}x3{} Blind chips' } },
    config = {},
    unlocked = false,
    apply = function(self, back)
        G.GAME.banachos_old = true
        add_joker('j_banachos_oldblue')
        add_joker('j_banachos_oldblack')
    end,
}

-- Mei Mei Deck: starts with Mei Mei, only 3 joker slots
SMODS.Back{
    key = 'meimei',
    atlas = 'meimei', pos = { x = 0, y = 0 },
    loc_txt = { name = 'Mei Mei Deck', text = { 'Start with {C:attention}Mei Mei{}', 'Joker slots: {C:attention}3{}' } },
    config = {},
    unlocked = false,
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({ func = function()
            if G.jokers then G.jokers.config.card_limit = 3 end
            return true
        end }))
        add_joker('j_banachos_meimei')
    end,
}

-- Banachos Deck: starts with one random Banachos joker (eternal)
local BANACHOS_KEYS = { 'j_banachos_threebirds', 'j_banachos_whereisbro', 'j_banachos_meimei', 'j_banachos_igotchu',
                        'j_banachos_oldblue', 'j_banachos_oldblack', 'j_banachos_secretagent',
                        'j_banachos_subway', 'j_banachos_happymeal', 'j_banachos_apple' }
SMODS.Back{
    key = 'banachos',
    atlas = 'threebirds', pos = { x = 0, y = 0 },
    loc_txt = { name = 'Banachos Deck', text = { 'Start with a random', '{C:attention}Banachos{} joker', 'with {C:attention}Eternal{}' } },
    config = {},
    unlocked = false,
    apply = function(self, back)
        local key = BANACHOS_KEYS[math.floor(pseudorandom('banachos_deck') * #BANACHOS_KEYS) + 1]
        add_joker(key, true)
    end,
}

-- Unlock checks when a run is won
local function set_unlocked(suffix)
    for k, v in pairs(G.P_CENTERS) do
        if v.set == 'Back' and k:find(suffix, 1, true) then v.unlocked = true end
    end
end

local old_update = Game.update
function Game:update(dt)
    old_update(self, dt)
    if not (G.GAME and G.GAME.won) or G.GAME.banachos_checked then return end
    G.GAME.banachos_checked = true
    local cards = jokers()
    local n = #cards
    local keys = {}
    for _, c in ipairs(cards) do keys[key_of(c)] = true end
    -- Old Deck: won with only the two old men
    if keys['j_banachos_oldblue'] and keys['j_banachos_oldblack'] and n == 2 then set_unlocked('banachos_old') end
    -- Mei Mei Deck: won with Mei Mei and at most 2 other jokers
    if keys['j_banachos_meimei'] and n <= 3 then set_unlocked('banachos_meimei') end
    -- Banachos Deck: won with only Banachos jokers
    local all_banachos = n > 0
    for _, c in ipairs(cards) do
        if not key_of(c):find('^j_banachos_') then all_banachos = false end
    end
    if all_banachos then set_unlocked('banachos_banachos') end
end

-- Old Deck: blind chips x3
local old_set_blind = Blind.set_blind
function Blind:set_blind(...)
    old_set_blind(self, ...)
    if G.GAME and G.GAME.banachos_old and not self.banachos_scaled then
        self.banachos_scaled = true
        self.chips = self.chips * 3
    end
end
