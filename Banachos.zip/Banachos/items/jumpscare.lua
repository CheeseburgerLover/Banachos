-- Three Birds jumpscare: the full image stretches over the screen, then fades out.
local img = nil
local state = nil -- { t = seconds elapsed }
local STRETCH, FADE = 0.4, 0.9   -- stretch duration, fade duration

function BANACHOS_JUMPSCARE_START()
    if BANACHOS and BANACHOS.perf then return end
    if not img then
        local mod = SMODS.findModByID and SMODS.findModByID('Banachos')
        if mod and mod.path then
            local ok, i = pcall(love.graphics.newImage, mod.path .. 'assets/jumpscare.png')
            if ok then img = i end
        end
    end
    state = { t = 0 }
end

local old_update = Game.update
function Game:update(dt)
    old_update(self, dt)
    if state then
        state.t = state.t + dt
        if state.t > STRETCH + FADE then state = nil end
    end
end

local old_draw = love.draw
function love.draw()
    old_draw()
    if not state or not img then return end
    local W, H = love.graphics.getDimensions()
    local alpha = 1
    if state.t > STRETCH then alpha = 1 - (state.t - STRETCH) / FADE end
    local sx = W / img:getWidth()
    local sy = H / img:getHeight()
    love.graphics.setColor(1, 1, 1, math.max(0, alpha))
    love.graphics.draw(img, 0, 0, 0, sx, sy)   -- stretched to cover the whole screen
    love.graphics.setColor(1, 1, 1, 1)
end
