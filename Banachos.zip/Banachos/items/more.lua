-- Extra Banachos jokers (balance and fun additions)
SMODS.Atlas{ key = 'chorus', path = 'chorus.png', px = 71, py = 95 }
SMODS.Atlas{ key = 'bet', path = 'bet.png', px = 71, py = 95 }

-- Chick Chorus (Uncommon): +3 Mult for each other Banachos joker you own
SMODS.Joker{
    key = 'chorus', atlas = 'chorus', pos = { x = 0, y = 0 }, display_size = { w = 71, h = 95 },
    loc_txt = { ['name'] = 'Chick Chorus', ['text'] = { '{C:mult}+3{} Mult for each', 'other {C:attention}Banachos{} joker' } },
    rarity = 2, cost = 6, unlocked = true, discovered = true, blueprint_compat = true, eternal_compat = true,
    calculate = function(self, card, context)
        if context.joker_main and G.jokers then
            local n = 0
            for _, c in ipairs(G.jokers.cards) do
                local k = c.config and c.config.center and c.config.center.key or ''
                if k:find('^j_banachos_') and c ~= card then n = n + 1 end
            end
            if n > 0 then return { mult = 3 * n, card = card } end
        end
    end,
}

-- Budgie Bet (Common): earn $2 at the end of each round if you own 3+ Banachos jokers
SMODS.Joker{
    key = 'bet', atlas = 'bet', pos = { x = 0, y = 0 }, display_size = { w = 71, h = 95 },
    loc_txt = { ['name'] = 'Budgie Bet', ['text'] = { 'Earn {C:money}$2{} at end of round', 'if you have {C:attention}3+{} Banachos jokers' } },
    rarity = 1, cost = 4, unlocked = true, discovered = true, blueprint_compat = false, eternal_compat = true,
    calculate = function(self, card, context)
        if context.end_of_round and context.cardarea == G.jokers and not context.blueprint and G.jokers then
            local n = 0
            for _, c in ipairs(G.jokers.cards) do
                local k = c.config and c.config.center and c.config.center.key or ''
                if k:find('^j_banachos_') then n = n + 1 end
            end
            if n >= 3 then return { dollars = 2, card = card } end
        end
    end,
}
