-- I gotchu: during a blind, the player BUYS an extra discard ($1 base) or an extra hand ($2 base).
-- For every $10 above $10, both prices go up by $1. Money can never go negative.
-- Example: $30 -> discard costs $3, hand costs $4.
SMODS.Atlas{ key = 'igotchu', path = 'igotchu.png', px = 71, py = 95 }

local JOKER_KEY = 'j_banachos_igotchu'

local function owns_joker()
    if not G.jokers then return false end
    for _, c in ipairs(G.jokers.cards) do
        if c.config and c.config.center and c.config.center.key == JOKER_KEY then return true end
    end
    return false
end

local function in_blind()
    if not G.GAME or not G.GAME.blind then return false end
    local s = G.STATE
    return s == G.STATES.SELECTING_HAND or s == G.STATES.HAND_PLAYED or s == G.STATES.DRAW_TO_HAND
end

-- base + floor((money - 10) / 10) when money is above 10
local function price(base)
    local money = G.GAME.dollars
    local extra = 0
    if money > 10 then extra = math.floor((money - 10) / 10) end
    return base + extra
end

local function buy(kind)
    if not (in_blind() and owns_joker()) then return end
    local base = (kind == 'discard') and 1 or 2
    local cost = price(base)
    if G.GAME.dollars < cost then return end       -- never go negative
    ease_dollars(-cost)
    if kind == 'discard' then
        G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + 1
    else
        G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + 1
    end
end

-- Buttons drawn on screen (left side, middle height) while the joker is owned during a blind
local function rects()
    local _, H = love.graphics.getDimensions()
    return {
        { x = 10, y = H * 0.5,        w = 170, h = 40, label = 'Buy discard $' .. price(1), act = function() buy('discard') end },
        { x = 10, y = H * 0.5 + 50,   w = 170, h = 40, label = 'Buy hand $'    .. price(2), act = function() buy('hand') end },
    }
end

local function inside(r, px, py)
    return px >= r.x and px <= r.x + r.w and py >= r.y and py <= r.y + r.h
end

local old_draw = love.draw
function love.draw()
    old_draw()
    if not (in_blind() and owns_joker()) then return end
    for _, b in ipairs(rects()) do
        love.graphics.setColor(0.1, 0.6, 0.2, 0.95)
        love.graphics.rectangle('fill', b.x, b.y, b.w, b.h, 6, 6)
        love.graphics.setColor(1, 1, 1, 1)
        love.graphics.print(b.label, b.x + 12, b.y + 12)
    end
    love.graphics.setColor(1, 1, 1, 1)
end

local old_mousepressed = love.mousepressed
function love.mousepressed(x, y, button, ...)
    if old_mousepressed then old_mousepressed(x, y, button, ...) end
    if button ~= 1 or not (in_blind() and owns_joker()) then return end
    for _, b in ipairs(rects()) do
        if inside(b, x, y) then b.act() return end
    end
end

SMODS.Joker{
    key = 'igotchu',
    atlas = 'igotchu',
    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },
    loc_txt = {
        ['name'] = 'I gotchu',
        ['text'] = {
            [1] = 'During a blind, you can {C:money}buy{}',
            [2] = '{C:attention}1 discard{} for {C:money}$1{} or {C:attention}1 hand{} for {C:money}$2{}',
            [3] = 'Every {C:money}$10{} above {C:money}$10{} adds {C:money}$1{} to both',
        },
    },
    rarity = 2,
    cost = 5,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
}
