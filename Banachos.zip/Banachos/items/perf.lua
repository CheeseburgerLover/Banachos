-- Shared performance flag and the Subway Joker frame animation (416 frames, 16 columns).
BANACHOS = BANACHOS or { perf = false }

local FRAMES, COLS = 416, 16
local clock = 0

local old_update = Game.update
function Game:update(dt)
    old_update(self, dt)
    clock = clock + dt
    local fps = BANACHOS.perf and 1 or 2
    local f = math.floor(clock * fps) % FRAMES
    local pos = { x = f % COLS, y = math.floor(f / COLS) }
    for _, area in ipairs({ G.jokers, G.shop_jokers, G.pack_cards }) do
        if area and area.cards then
            for _, c in ipairs(area.cards) do
                if c.config and c.config.center and c.config.center.key == 'j_banachos_subway'
                   and c.children and c.children.center then
                    c.children.center:set_sprite_pos(pos)
                end
            end
        end
    end
end
