-- Three Birds: triggers on scoring cards of rank 3, 6 or 9. Sells for 5 (cost 10).
SMODS.Atlas{ key = 'threebirds', path = 'threebirds.png', px = 71, py = 95 }

SMODS.Joker{
    key = 'threebirds',
    atlas = 'threebirds',
    pos = { x = 0, y = 0 },
    display_size = { w = 71, h = 95 },
    config = { extra = { chips = 50, mult = 15, x_mult = 1.5 } },
    loc_txt = {
        ['name'] = 'Three Birds',
        ['text'] = {
            [1] = 'Each played {C:attention}3{}, {C:attention}6{} or {C:attention}9{}',
            [2] = 'gives {C:chips}+#1#{} Chips',
            [3] = '{C:green}2/3{} chance for {C:mult}+#2#{} Mult',
            [4] = '{C:green}1/3{} chance for {X:mult,C:white}X#3#{} Mult',
        },
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips, card.ability.extra.mult, card.ability.extra.x_mult } }
    end,
    rarity = 1,
    cost = 10,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,

    calculate = function(self, card, context)
        -- 20% chance when sold: trigger the jumpscare
        if context.selling_self and not context.blueprint then
            if pseudorandom('threebirds_scare') < 0.2 then
                BANACHOS_JUMPSCARE_START()
            end
            return
        end
        if context.individual and context.cardarea == G.play then
            local id = context.other_card:get_id()
            if id == 3 or id == 6 or id == 9 then
                if pseudorandom('threebirds_mult') < 2/3 then
                    return { chips = card.ability.extra.chips, mult = card.ability.extra.mult, card = card }
                else
                    return { chips = card.ability.extra.chips, x_mult = card.ability.extra.x_mult, card = card }
                end
            end
        end
    end,
}
