--- STEAMODDED HEADER
--- MOD_NAME: Banachos
--- MOD_ID: Banachos
--- MOD_AUTHOR: Thienje
--- MOD_DESCRIPTION: Budgie and cockatiel themed jokers.
--- PREFIX: banachos

SMODS.load_file("items/perf.lua")()
SMODS.load_file("items/threebirds.lua")()
SMODS.load_file("items/jumpscare.lua")()
SMODS.load_file("items/whereisbro.lua")()
SMODS.load_file("items/pack.lua")()
SMODS.load_file("items/igotchu.lua")()
SMODS.load_file("items/meimei.lua")()
SMODS.load_file("items/batch2.lua")()
SMODS.load_file("items/apple.lua")()
SMODS.load_file("items/decks.lua")()
SMODS.load_file("items/ideas.lua")()
SMODS.load_file("items/more.lua")()
SMODS.load_file("items/vi.lua")()
