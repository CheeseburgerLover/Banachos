-- Vietnamese text for Banachos. Steamodded parses this file (the crash came from merging raw tables at runtime).
return {
    descriptions = {
        Joker = {
            j_banachos_threebirds = { name = 'Ba Con Chim', text = {
                'Mỗi lá {C:attention}3{}, {C:attention}6{} hoặc {C:attention}9{} được tính điểm',
                'cho {C:chips}+#1#{} Chip', '{C:green}2/3{} cơ hội {C:mult}+#2#{} Mult', '{C:green}1/3{} cơ hội {X:mult,C:white}X#3#{} Mult' } },
            j_banachos_whereisbro = { name = 'Where is bro going', text = {
                'Bỏ một {C:attention}Thùng{}, {C:attention}Sảnh{}, {C:attention}Cù lũ{},',
                '{C:attention}Sảnh thùng{} hoặc {C:attention}#1#{} để tích {C:mult}+30{} Mult',
                'và {X:mult,C:white}X1.33{} Mult cho lần đánh tiếp theo' } },
            j_banachos_meimei = { name = 'Mei Mei', text = {
                'Phát video khi tính điểm', 'và {X:mult,C:white}X#1#{} Mult', '{C:inactive}Art by Luna{}' } },
            j_banachos_igotchu = { name = 'I gotchu', text = {
                'Trong trận, bạn có thể {C:money}mua{} thêm',
                '{C:attention}1 lượt bỏ bài{} với {C:money}$1{} hoặc {C:attention}1 lượt đánh{} với {C:money}$2{}',
                'Cứ mỗi {C:money}$10{} trên {C:money}$10{} thì giá tăng {C:money}$1{}' } },
            j_banachos_oldblue = { name = 'Ông già Áo Xanh', text = {
                '{C:chips}+#1#{} Chip, {C:mult}+#2#{} Mult',
                'Có Ông già Áo Đen: {C:chips}+#3#{} Chip, {C:mult}+#4#{} Mult' } },
            j_banachos_oldblack = { name = 'Ông già Áo Đen', text = {
                '{X:mult,C:white}X#1#{} Mult', 'Có Ông già Áo Xanh: {X:mult,C:white}X#2#{} Mult' } },
            j_banachos_secretagent = { name = 'Secret Agent', text = {
                '{X:mult,C:white}X1{} Mult, cộng thêm {X:mult,C:white}0.2{} cho mỗi',
                'lần đánh hand chơi nhiều nhất (tối đa {X:mult,C:white}X5{})' } },
            j_banachos_subway = { name = 'Subway Joker', text = {
                'Đổi {C:attention}10%{} Chip thành {C:mult}Mult{}', '(tối đa {C:mult}60{})' } },
            j_banachos_happymeal = { name = 'Happy Meal', text = {
                '{C:attention}+2{} số lá tối đa, {C:attention}+1{} lượt bỏ bài, {C:attention}+1{} lượt đánh',
                'Cuối vòng: {C:green}1/4{} cơ hội mất 1 buff',
                'Mất hết buff thì nổ và tặng một lá {C:planet}Hành tinh{}' } },
            j_banachos_apple = { name = 'Apple Joker', text = {
                'Giá trong shop {C:money}x2{}',
                'Retrigger {C:attention}Apple Seal{} 1 lần',
                'Lá đầu tiên mỗi hand nhận {C:attention}Apple Seal{}' } },
            j_banachos_crest = { name = 'Cockatiel Crest', text = {
                '{C:mult}+1{} Mult mỗi lá {C:attention}Ace{} được tính', '(tối đa {C:mult}+50{} mỗi hand)' } },
            j_banachos_flock = { name = 'Flock Event', text = {
                'Cứ 5 round: tích thêm {X:mult,C:white}+0.1{} X Mult', 'Đang tích: {X:mult,C:white}X#1#{}' } },
            j_banachos_chorus = { name = 'Chick Chorus', text = {
                '{C:mult}+3{} Mult cho mỗi joker {C:attention}Banachos{} khác', 'bạn đang có' } },
            j_banachos_bet = { name = 'Budgie Bet', text = {
                'Nhận {C:money}$2{} cuối round', 'nếu có từ {C:attention}3{} joker Banachos trở lên' } },
        },
    },
}
